import { app, BrowserWindow, ipcMain, type IpcMainEvent, type IpcMainInvokeEvent } from 'electron'
import { APP_IPC, type MediaFolder } from '../shared/app'
import { CAPTURE_IPC, type CaptureSessionState } from '../shared/capture'
import path from 'node:path'
import { arm, beginRecording, focusWindow, captureFolder, captureFree, discardRecording, finishRecording, forgetRecording, helperState, listSources, pickCaptureFolder, recoverable, recoverRecording, resetCaptureFolder, setSession, startAppAudio, startCursor, stopStream, windowInfo } from './capture'
import { collectProject } from './collect'
import { abortExport, beginExport, beginFile, finishExport, forgetPicked, openPicked, pickExport, restartExport, writeExport, writeFrame, writeSidecar, type ExportRequest } from './export'
import { mediaRoot } from './integrations/paths'
import { listVersions } from './versions'
import { openPath, pickMedia, register, relink, reveal, saveMedia, urlForPath } from './files'
import { gpuInfo, setGraphicsSettings } from './gpu'
import { sendLive, startLive, stopLive } from './live'
import { attachEditor, completeClip, failClip, ingestState, openSession, pickIngestFolder, regenerateIngestToken, reportProgress, setIngestOptions, startIngest, stopIngest } from './ingest'
import type { IngestResult } from '../shared/ingest'
import { listRenders, removeRenders, renderUsage, writeRender } from './render-cache'
import { closeNow, confirmDiscard, forgetRecent, openProject, openVersion, readRecovery, recentProjects, saveProject, saveProjectAs, setProjectState, snapshotVersion, writeRecovery } from './project'
import { checkForUpdates, installUpdate, updateState } from './updater'

const FOLDERS: MediaFolder[] = ['snapshots', 'recordings', 'sfx', 'generated']

/** File, project and export IPC — only the editor's own page may call it. */
export function registerAppIpc(isTrustedUrl: (url: string) => boolean, getStartupFile: () => string | null) {
  const trusted = (event: IpcMainInvokeEvent | IpcMainEvent) => isTrustedUrl(event.senderFrame?.url ?? '')
  const winOf = (event: IpcMainInvokeEvent | IpcMainEvent) => BrowserWindow.fromWebContents(event.sender)
  const handle = <A extends unknown[], R>(channel: string, fn: (win: BrowserWindow | null, ...args: A) => R) => {
    ipcMain.handle(channel, (event, ...args: unknown[]) => {
      if (!trusted(event)) throw new Error('Blocked: untrusted sender')
      return fn(winOf(event), ...(args as A))
    })
  }
  const on = <A extends unknown[]>(channel: string, fn: (win: BrowserWindow, ...args: A) => void) => {
    ipcMain.on(channel, (event, ...args: unknown[]) => {
      const win = winOf(event)
      if (trusted(event) && win) fn(win, ...(args as A))
    })
  }
  const str = (v: unknown) => (typeof v === 'string' ? v : '')

  handle(APP_IPC.pickMedia, (win) => pickMedia(win))
  handle(APP_IPC.registerMedia, (_win, paths: unknown) => register(Array.isArray(paths) ? paths.filter((p): p is string => typeof p === 'string') : []))
  handle(APP_IPC.relinkMedia, (win, name: unknown) => relink(win, str(name)))
  handle(APP_IPC.revealFile, (_win, target: unknown) => reveal(str(target)))
  handle(APP_IPC.openFile, (_win, target: unknown) => openPath(str(target)))
  handle(APP_IPC.saveMedia, (_win, folder: unknown, name: unknown, data: unknown) => {
    if (!FOLDERS.includes(folder as MediaFolder)) throw new Error('Unknown media folder')
    if (!(data instanceof Uint8Array)) throw new Error('Expected bytes')
    return saveMedia(folder as MediaFolder, str(name) || 'media', data)
  })
  handle(APP_IPC.mediaUrlForPath, (_win, p: unknown) => (str(p) ? urlForPath(str(p)) : null))
  handle(APP_IPC.proxyBegin, (_win, key: unknown) => {
    const name = str(key).replace(/[^\w-]/g, '').slice(0, 120)
    if (!name) throw new Error('Bad proxy name')
    return beginFile(path.join(mediaRoot(), 'proxies', `${name}.mp4`))
  })
  handle(APP_IPC.renderWrite, (_win, projectId: unknown, key: unknown, data: unknown) => writeRender(str(projectId), str(key), data as Uint8Array))
  handle(APP_IPC.renderList, (_win, projectId: unknown) => listRenders(str(projectId)))
  handle(APP_IPC.renderRemove, (_win, projectId: unknown, keys: unknown) =>
    removeRenders(str(projectId), Array.isArray(keys) ? keys.filter((k): k is string => typeof k === 'string') : null),
  )
  handle(APP_IPC.renderUsage, () => renderUsage())

  handle(APP_IPC.projectOpen, (win, file?: unknown) => openProject(win, typeof file === 'string' && file ? file : undefined))
  handle(APP_IPC.projectSave, (_win, file: unknown, text: unknown) => saveProject(str(file), str(text)))
  handle(APP_IPC.projectSaveAs, (win, name: unknown, text: unknown) => saveProjectAs(win, str(name), str(text)))
  handle(APP_IPC.projectRecent, () => recentProjects())
  handle(APP_IPC.projectForget, (_win, file: unknown) => forgetRecent(str(file)))
  handle(APP_IPC.projectAutosave, (_win, snap: unknown) => {
    const s = snap as { text?: unknown; path?: unknown; name?: unknown } | null
    writeRecovery(s && typeof s.text === 'string' ? { text: s.text, path: typeof s.path === 'string' ? s.path : null, name: str(s.name) || 'Untitled' } : null)
  })
  handle(APP_IPC.projectRecovery, () => readRecovery())
  handle(APP_IPC.projectDiscardRecovery, () => writeRecovery(null))
  handle(APP_IPC.projectStartup, () => getStartupFile())
  handle(APP_IPC.projectVersions, (_win, projectId: unknown) => listVersions(str(projectId)))
  handle(APP_IPC.projectReadVersion, (_win, projectId: unknown, versionId: unknown, projectPath: unknown) => openVersion(str(projectId), str(versionId), str(projectPath) || null))
  handle(APP_IPC.projectSnapshot, (_win, snap: unknown) => {
    const s = (snap ?? {}) as { text?: unknown; path?: unknown; kind?: unknown }
    if (typeof s.text !== 'string') return
    const kind = s.kind === 'restore' ? 'restore' : 'auto'
    snapshotVersion({ text: s.text, path: typeof s.path === 'string' ? s.path : null, kind })
  })
  handle(APP_IPC.projectCollect, (win, name: unknown, text: unknown) => collectProject(win, str(text), str(name) || 'Untitled', (file, t) => saveProject(file, t)))
  handle(APP_IPC.confirmDiscard, (win, name: unknown) => confirmDiscard(win, str(name) || 'Untitled'))
  on(APP_IPC.projectState, (win, state: unknown) => setProjectState(win, (state ?? {}) as Record<string, unknown>))
  on(APP_IPC.closeWindow, (win) => closeNow(win))

  handle(APP_IPC.liveStart, (_win, raw: unknown) => {
    const value = (raw ?? {}) as Record<string, unknown>
    startLive({ endpoint: typeof value.endpoint === 'string' ? value.endpoint : '', streamKey: typeof value.streamKey === 'string' ? value.streamKey : '', width: Number(value.width), height: Number(value.height), fps: Number(value.fps), bitrate: Number(value.bitrate) })
  })
  on(APP_IPC.liveData, (_win, data: unknown) => { if (data instanceof Uint8Array) sendLive(data) })
  handle(APP_IPC.liveStop, () => stopLive())

  const request = (opts: unknown): ExportRequest => {
    const o = (opts ?? {}) as { defaultName?: unknown; extension?: unknown; filterName?: unknown; folder?: unknown }
    return { defaultName: str(o.defaultName), extension: str(o.extension), filterName: str(o.filterName), folder: o.folder === true }
  }
  handle(APP_IPC.exportBegin, (win, opts: unknown) => beginExport(win, request(opts)))
  handle(APP_IPC.exportPick, (win, opts: unknown) => pickExport(win, request(opts)))
  handle(APP_IPC.exportOpen, (_win, token: unknown) => openPicked(str(token)))
  handle(APP_IPC.exportForget, (_win, token: unknown) => forgetPicked(str(token)))
  handle(APP_IPC.exportWrite, (_win, id: unknown, position: unknown, data: unknown) => writeExport(str(id), Number(position), data as Uint8Array))
  handle(APP_IPC.exportFrame, (_win, id: unknown, index: unknown, data: unknown) => writeFrame(str(id), Number(index), data as Uint8Array))
  handle(APP_IPC.exportSidecar, (_win, file: unknown, ext: unknown, text: unknown) => writeSidecar(str(file), str(ext), str(text)))
  handle(APP_IPC.exportRestart, (_win, id: unknown) => restartExport(str(id)))
  handle(APP_IPC.exportFinish, (_win, id: unknown) => finishExport(str(id)))
  handle(APP_IPC.exportAbort, (_win, id: unknown) => abortExport(str(id)))
  on(APP_IPC.exportProgress, (win, value: unknown) => {
    const v = typeof value === 'number' && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : -1
    win.setProgressBar(v)
  })

  // What the user sees — for the Copilot's editor screenshots. Only this window, never the screen.
  handle(APP_IPC.captureWindow, async (win, maxWidth: unknown) => {
    if (!win || win.isDestroyed()) throw new Error('No editor window')
    const image = await win.webContents.capturePage()
    const width = Math.round(Math.min(2560, Math.max(320, typeof maxWidth === 'number' && Number.isFinite(maxWidth) ? maxWidth : 1600)))
    const scaled = image.getSize().width > width ? image.resize({ width, quality: 'good' }) : image
    return scaled.toJPEG(82).toString('base64')
  })

  handle(APP_IPC.ingestState, () => ingestState())
  handle(APP_IPC.ingestSetEnabled, (_win, on: unknown, persist: unknown) => (on ? startIngest(persist !== false) : stopIngest(persist !== false)))
  handle(APP_IPC.ingestRegenerate, () => regenerateIngestToken())
  handle(APP_IPC.ingestOptions, (_win, opts: unknown) => setIngestOptions((opts ?? {}) as { quality?: unknown; folder?: unknown }))
  handle(APP_IPC.ingestPickFolder, (win) => pickIngestFolder(win))
  handle(APP_IPC.ingestAttach, () => attachEditor())
  handle(APP_IPC.ingestOpen, (_win, clipId: unknown, wantProxy: unknown) => openSession(str(clipId), wantProxy === true))
  handle(APP_IPC.ingestComplete, (_win, clipId: unknown, result: unknown) => completeClip(str(clipId), (result ?? {}) as IngestResult))
  handle(APP_IPC.ingestFail, (_win, clipId: unknown, message: unknown) => failClip(str(clipId), str(message)))
  on(APP_IPC.ingestProgress, (_win, clipId: unknown, encoded: unknown) => reportProgress(str(clipId), Number(encoded)))
  // Screen recording. The picture itself never passes through here: the editor asks Chromium for it.
  const target = (v: unknown) => {
    const t = (v ?? {}) as { hwnd?: unknown; pid?: unknown; hz?: unknown }
    return { hwnd: typeof t.hwnd === 'number' ? t.hwnd : undefined, pid: typeof t.pid === 'number' ? t.pid : undefined, hz: typeof t.hz === 'number' ? t.hz : undefined }
  }
  handle(CAPTURE_IPC.sources, (_win, opts: unknown) => {
    const o = (opts ?? {}) as { thumbnails?: unknown; icons?: unknown }
    return listSources({ thumbnails: o.thumbnails === true, icons: o.icons === true })
  })
  handle(CAPTURE_IPC.arm, (_win, sourceId: unknown, systemAudio: unknown) => arm(str(sourceId), systemAudio === true))
  handle(CAPTURE_IPC.helper, () => helperState())
  handle(CAPTURE_IPC.folder, () => captureFolder())
  handle(CAPTURE_IPC.pickFolder, (win) => pickCaptureFolder(win))
  handle(CAPTURE_IPC.resetFolder, () => resetCaptureFolder())
  handle(CAPTURE_IPC.begin, (_win, name: unknown, extension: unknown) => beginRecording(str(name), str(extension)))
  handle(CAPTURE_IPC.finish, (_win, id: unknown) => finishRecording(str(id)))
  handle(CAPTURE_IPC.discard, (_win, id: unknown) => discardRecording(str(id)))
  handle(CAPTURE_IPC.free, () => captureFree())
  handle(CAPTURE_IPC.appAudioStart, (_win, key: unknown, t: unknown) => startAppAudio(str(key), target(t)))
  handle(CAPTURE_IPC.cursorStart, (_win, key: unknown, t: unknown) => startCursor(str(key), target(t)))
  handle(CAPTURE_IPC.streamStop, (_win, key: unknown) => stopStream(str(key)))
  handle(CAPTURE_IPC.windowInfo, (_win, hwnd: unknown) => windowInfo(Number(hwnd)))
  handle(CAPTURE_IPC.focus, (win, hwnd: unknown) => focusWindow(win, typeof hwnd === 'number' ? hwnd : undefined))
  handle(CAPTURE_IPC.recoverable, () => recoverable())
  handle(CAPTURE_IPC.recover, (_win, file: unknown) => recoverRecording(str(file)))
  handle(CAPTURE_IPC.forget, (_win, file: unknown) => forgetRecording(str(file)))
  on(CAPTURE_IPC.session, (win, state: unknown) => setSession(win, (state ?? {}) as Partial<CaptureSessionState>))

  handle(APP_IPC.gpuInfo, () => gpuInfo())
  handle(APP_IPC.graphicsSet, (_win, patch: unknown) => {
    setGraphicsSettings((patch ?? {}) as Record<string, never>)
    return gpuInfo()
  })
  // The editor saves first, so this closes without the unsaved-changes prompt.
  on(APP_IPC.relaunch, (win) => {
    app.relaunch()
    closeNow(win)
  })

  handle(APP_IPC.updateState, () => updateState())
  handle(APP_IPC.updateCheck, () => checkForUpdates())
  handle(APP_IPC.updateInstall, () => installUpdate())
}
